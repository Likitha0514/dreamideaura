class ProductEntity {
  const ProductEntity({
    required this.id,
    required this.name,
    required this.sellingPrice,
    required this.date,
    required this.effortContributorIds,
    required this.marketingContributorIds,
  });

  final String id;
  final String name;
  final double sellingPrice;
  final DateTime date;
  final List<String> effortContributorIds;
  final List<String> marketingContributorIds;
}