// Member activation status.
