// Date formatting helpers.
