// Currency formatting helpers.
