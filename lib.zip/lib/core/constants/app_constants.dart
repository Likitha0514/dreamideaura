// Application-wide constants.
