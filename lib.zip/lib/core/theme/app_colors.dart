// Application color palette.
